from pymongo import MongoClient
from pymongo.errors import PyMongoError

class AnimalShelter(object):
    def __init__(self, username, password):
        HOST = "localhost"
        PORT = 27017
        DB = "aac"
        COL = "animals"

        try:
            uri = "mongodb://%s:%s@%s:%d/?authSource=admin" % (
                username, password, HOST, PORT
            )

            self.client = MongoClient(uri)
            self.database = self.client[DB]
            self.collection = self.database[COL]

            self.client.admin.command("ping")

        except PyMongoError as e:
            raise ConnectionError(f"MongoDB connection failed: {e}") from e


    # -------------------------------
    # C = CREATE
    # -------------------------------
    def create(self, data):
        """
        Insert a document into the animals collection.

        Args:
            data (dict): A dictionary of key/value pairs
                         representing the MongoDB document.

        Returns:
            bool: True if insert is successful, False otherwise.
        """

        # Validate input
        if data is None or not isinstance(data, dict) or len(data) == 0:
            return False

        try:
            # Insert document into MongoDB
            result = self.collection.insert_one(data)

            # acknowledged == True means insert succeeded
            return result.acknowledged

        except PyMongoError:
            return False

    # -------------------------------
    # R = READ
    # -------------------------------
    def read(self, query):
        """
        Query documents from the animals collection.

        Args:
            query (dict): Key/value lookup pairs for filtering documents.

        Returns:
            program will make a list of matching documents, or an empty list if none found.
        """

        # Default to empty query (return all documents)
        if query is None:
            query = {}

        # Ensure query is a dictionary
        if not isinstance(query, dict):
            return []

        try:
            # Execute query using find()
            cursor = self.collection.find(query)

            # Convert cursor to list and return
            return list(cursor)

        except PyMongoError:
            return []
    # -------------------------------
    # U = UPDATE
    # -------------------------------
    def update(self, query, new_values, many=False):
        """
        Update document(s) in the animals collection.

        Args:
            query (dict): Key/value lookup pairs to match documents.
            new_values (dict): Key/value pairs to update (fields and new values).
            many (bool): If True, update many documents; else update one.

        Returns:
            int: Number of documents modified.
        """
        if query is None or not isinstance(query, dict):
            return 0

        if new_values is None or not isinstance(new_values, dict) or len(new_values) == 0:
            return 0

        try:
            update_doc = {"$set": new_values}

            if many:
                result = self.collection.update_many(query, update_doc)
            else:
                result = self.collection.update_one(query, update_doc)

            return result.modified_count

        except PyMongoError:
            return 0

    # -------------------------------
    # D = DELETE
    # -------------------------------
    def delete(self, query, many=False):
        """
        Delete document(s) from the animals collection.

        Args:
            query (dict): Key/value lookup pairs to match documents.
            many (bool): If True, delete many documents; else delete one.

        Returns:
            int: Number of documents deleted.
        """
        if query is None or not isinstance(query, dict) or len(query) == 0:
            # safety: don't allow delete-all
            return 0

        try:
            if many:
                result = self.collection.delete_many(query)
            else:
                result = self.collection.delete_one(query)

            return result.deleted_count

        except PyMongoError:
            return 0
